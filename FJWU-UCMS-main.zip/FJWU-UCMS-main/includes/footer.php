<footer class="text-center mt-5 py-3">
  <p>&copy; <?php echo date('Y'); ?> Fatima Jinnah Women University - UCMS Project</p>
</footer>

<!-- Bootstrap JS with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script src="<?php echo $base_path; ?>/assets/js/main.js"></script>
</body>
</html>
